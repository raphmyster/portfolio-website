/* Hero meta + Gallery variants */

const META_FACTS = [
  { k: "Based", v: "Toronto" },
  { k: "Role", v: "Builder / Ops" },
  { k: "Now", v: "Credit Sesame" },
  { k: "Open to", v: "Conversations" },
];

function HeroMeta() {
  const [variant, setVariant] = React.useState(() => {
    try { return (JSON.parse(localStorage.getItem("tweaks")) || {}).heroMeta || "strip"; }
    catch (_) { return "strip"; }
  });
  React.useEffect(() => {
    function onMsg(e) {
      if (e.data && e.data.type === "__tweak_changed" && e.data.key === "heroMeta") {
        setVariant(e.data.value);
      }
    }
    window.addEventListener("message", onMsg);
    return () => window.removeEventListener("message", onMsg);
  }, []);

  if (variant === "ticker") {
    return (
      <div className="hero-meta-ticker reveal">
        <div className="hmt-track">
          {[...Array(3)].map((_, j) => (
            <React.Fragment key={j}>
              {META_FACTS.map((f, i) => (
                <React.Fragment key={i}>
                  <span className="hmt-k">{f.k.toUpperCase()}</span>
                  <span className="hmt-v">{f.v}</span>
                  <span className="hmt-sep">▸</span>
                </React.Fragment>
              ))}
              <span className="hmt-k accent">STATUS</span>
              <span className="hmt-v"><span className="hmt-live" /> AVAILABLE TO TALK</span>
              <span className="hmt-sep">▸</span>
            </React.Fragment>
          ))}
        </div>
      </div>
    );
  }

  if (variant === "coords") {
    return (
      <div className="hero-meta-coords r-stagger reveal">
        {META_FACTS.map((f, i) => (
          <div className="hmc-cell" key={i}>
            <span className="hmc-idx">{String(i + 1).padStart(2, "0")}</span>
            <span className="hmc-k">{f.k}</span>
            <span className="hmc-v">{f.v}</span>
            <span className="hmc-corner tl" /><span className="hmc-corner tr" />
            <span className="hmc-corner bl" /><span className="hmc-corner br" />
          </div>
        ))}
      </div>
    );
  }

  // strip (default)
  return (
    <div className="hero-meta r-stagger reveal">
      {META_FACTS.map((f, i) => (
        <span key={i}><b>{f.k}</b> · {f.v}</span>
      ))}
    </div>
  );
}

/* Gallery variants */
const GALLERY2 = [
  { code: "ARC-01", title: "Urban Infill Residence", type: "Architecture", year: "2018", caption: "Mixed-use residential in Toronto's east end. Plan diagrams and structural details.", kind: "plan" },
  { code: "INT-02", title: "Retail Showroom", type: "Interior", year: "2017", caption: "Flagship FF&E showroom, 4,200 sq ft. Material palette studies and lighting plan.", kind: "swatch" },
  { code: "STU-03", title: "Ski Chalet Study", type: "Architecture", year: "2015", caption: "Site-integrated concept. Sections through a Laurentian hillside.", kind: "section" },
  { code: "IND-04", title: "Adaptive Reuse", type: "Interior", year: "2019", caption: "Warehouse-to-office conversion. Reflected ceiling and systems overlay.", kind: "axon" },
];

function GalleryGlyph({ kind }) {
  // Architectural placeholder SVGs per project type
  const glyphs = {
    plan: (
      <svg viewBox="0 0 200 140" width="100%" height="100%">
        <rect x="10" y="10" width="180" height="120" fill="none" stroke="currentColor" strokeWidth="0.8"/>
        <line x1="10" y1="60" x2="120" y2="60" stroke="currentColor" strokeWidth="0.6"/>
        <line x1="120" y1="10" x2="120" y2="130" stroke="currentColor" strokeWidth="0.6"/>
        <line x1="60" y1="60" x2="60" y2="130" stroke="currentColor" strokeWidth="0.6"/>
        <line x1="120" y1="90" x2="190" y2="90" stroke="currentColor" strokeWidth="0.6"/>
        {/* door arcs */}
        <path d="M60 60 A 20 20 0 0 1 80 40" fill="none" stroke="currentColor" strokeWidth="0.5" opacity="0.7"/>
        <path d="M120 90 A 16 16 0 0 1 136 74" fill="none" stroke="currentColor" strokeWidth="0.5" opacity="0.7"/>
        {/* hatch */}
        <rect x="130" y="20" width="50" height="30" fill="none" stroke="var(--accent)" strokeWidth="0.6"/>
        <line x1="130" y1="50" x2="180" y2="20" stroke="var(--accent)" strokeWidth="0.4" opacity="0.6"/>
        {/* dim line */}
        <line x1="10" y1="136" x2="190" y2="136" stroke="currentColor" strokeWidth="0.4" opacity="0.5"/>
        <text x="100" y="134" textAnchor="middle" fill="currentColor" fontSize="5" fontFamily="monospace" opacity="0.6">18.4 m</text>
      </svg>
    ),
    swatch: (
      <svg viewBox="0 0 200 140" width="100%" height="100%">
        {[...Array(6)].map((_, i) => (
          <rect key={i} x={14 + i * 30} y="20" width="24" height="60" fill="none" stroke="currentColor" strokeWidth="0.8" opacity={0.4 + i * 0.08}/>
        ))}
        <rect x="74" y="20" width="24" height="60" fill="var(--accent)" opacity="0.4"/>
        {[...Array(8)].map((_, i) => (
          <circle key={i} cx={20 + i * 22} cy="110" r="6" fill="none" stroke="currentColor" strokeWidth="0.6"/>
        ))}
      </svg>
    ),
    section: (
      <svg viewBox="0 0 200 140" width="100%" height="100%">
        <path d="M10 110 L 60 90 L 90 70 L 130 55 L 170 75 L 190 95 L 190 130 L 10 130 Z" fill="none" stroke="currentColor" strokeWidth="0.8"/>
        <rect x="80" y="40" width="50" height="40" fill="none" stroke="var(--accent)" strokeWidth="1"/>
        <line x1="80" y1="55" x2="130" y2="55" stroke="var(--accent)" strokeWidth="0.5"/>
        <line x1="105" y1="40" x2="105" y2="80" stroke="var(--accent)" strokeWidth="0.5"/>
        {/* ground hatch */}
        {[...Array(14)].map((_, i) => (
          <line key={i} x1={10 + i * 13} y1="130" x2={15 + i * 13} y2="138" stroke="currentColor" strokeWidth="0.4"/>
        ))}
        <text x="100" y="20" textAnchor="middle" fill="currentColor" fontSize="6" fontFamily="monospace" opacity="0.5">SECTION A-A</text>
      </svg>
    ),
    axon: (
      <svg viewBox="0 0 200 140" width="100%" height="100%">
        {/* axonometric box */}
        <path d="M60 90 L 120 90 L 150 70 L 90 70 Z" fill="none" stroke="currentColor" strokeWidth="0.8"/>
        <path d="M60 90 L 60 50 L 90 30 L 90 70" fill="none" stroke="currentColor" strokeWidth="0.8"/>
        <path d="M120 90 L 120 50 L 90 30" fill="none" stroke="currentColor" strokeWidth="0.8"/>
        <path d="M150 70 L 150 30 L 120 50 M 120 50 L 90 30" fill="none" stroke="currentColor" strokeWidth="0.8" opacity="0.5"/>
        <path d="M90 30 L 90 70 M 90 70 L 150 70" fill="none" stroke="currentColor" strokeWidth="0.8" opacity="0.3" strokeDasharray="2 2"/>
        {/* accent overlay */}
        <rect x="75" y="60" width="20" height="16" fill="var(--accent)" opacity="0.5"/>
        {/* grid */}
        {[...Array(5)].map((_, i) => (
          <line key={i} x1="20" y1={20 + i * 25} x2="40" y2={20 + i * 25} stroke="currentColor" strokeWidth="0.3" opacity="0.4"/>
        ))}
      </svg>
    ),
  };
  return glyphs[kind] || glyphs.plan;
}

function Gallery() {
  const [variant, setVariant] = React.useState(() => {
    try { return (JSON.parse(localStorage.getItem("tweaks")) || {}).gallery || "grid"; }
    catch (_) { return "grid"; }
  });
  React.useEffect(() => {
    function onMsg(e) {
      if (e.data && e.data.type === "__tweak_changed" && e.data.key === "gallery") {
        setVariant(e.data.value);
      }
    }
    window.addEventListener("message", onMsg);
    return () => window.removeEventListener("message", onMsg);
  }, []);

  if (variant === "stacked") {
    return (
      <div className="gallery-stacked">
        {GALLERY2.map((g, i) => (
          <article className={`gs-row reveal ${i % 2 ? "gs-flip" : ""}`} key={i}>
            <div className="gs-meta">
              <span className="gs-idx">FIG.{String(i + 1).padStart(2, "0")}</span>
              <h3 className="gs-title">{g.title}</h3>
              <span className="gs-type">{g.type} &nbsp;/&nbsp; {g.year}</span>
              <p className="gs-caption">{g.caption}</p>
            </div>
            <div className="gs-vis" style={{ color: "var(--fg-dim)" }}>
              <span className="gs-stamp">{g.code}</span>
              <GalleryGlyph kind={g.kind} />
            </div>
          </article>
        ))}
      </div>
    );
  }

  if (variant === "sheet") {
    return (
      <div className="gallery-sheet">
        <div className="gsh-header">
          <span>CONTACT SHEET / 01</span>
          <span>RAA — SELECTED WORK 2015–2019</span>
          <span>{GALLERY2.length} / {GALLERY2.length}</span>
        </div>
        <div className="gsh-grid">
          {GALLERY2.map((g, i) => (
            <figure className="gsh-item reveal" key={i}>
              <div className="gsh-notch l" /><div className="gsh-notch r" />
              <div className="gsh-frame" style={{ color: "var(--fg-dim)" }}>
                <GalleryGlyph kind={g.kind} />
                <span className="gsh-num">{String(i + 1).padStart(2, "0")}</span>
              </div>
              <figcaption>
                <span className="gsh-code">{g.code}</span>
                <span className="gsh-title">{g.title}</span>
                <span className="gsh-type">{g.type} · {g.year}</span>
              </figcaption>
            </figure>
          ))}
        </div>
        <div className="gsh-footer">
          <span>▸ RAA-PORTFOLIO-2026</span>
          <span>ARCH / INT</span>
          <span>{new Date().getFullYear()}</span>
        </div>
      </div>
    );
  }

  // grid (default) — refreshed asymmetric layout
  return (
    <div className="gallery-grid">
      {GALLERY2.map((g, i) => (
        <figure className={`gg-item gg-${i} reveal`} key={i}>
          <div className="gg-frame" style={{ color: "var(--fg-dim)" }}>
            <div className="gg-head">
              <span>{g.code}</span>
              <span>FIG.{String(i + 1).padStart(2, "0")}</span>
            </div>
            <div className="gg-vis"><GalleryGlyph kind={g.kind} /></div>
            <div className="gg-caption">
              <h3>{g.title}</h3>
              <span>{g.type} &nbsp;/&nbsp; {g.year}</span>
              <p>{g.caption}</p>
            </div>
          </div>
        </figure>
      ))}
    </div>
  );
}

window.HeroMeta = HeroMeta;
window.GalleryGlyph = GalleryGlyph;
window.Gallery = Gallery;
