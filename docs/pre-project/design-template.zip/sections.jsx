/* Timeline, gallery, footer components */

const TIMELINE = [
  {
    years: "2025 — Present", label: "NOW / AI",
    title: "Building with AI",
    body: "Personal projects using AI-assisted development tools. Chrome extensions, native apps, automation pipelines — most of them solving problems I encountered myself.",
    branch: true, now: true,
  },
  {
    years: "2019 — Present", label: "NOW / OPS",
    title: "Credit Sesame",
    body: "Marketing operations at a consumer fintech. CRM, lifecycle automation, attribution, and the systems behind how a financial product actually grows.",
    branch: true, now: true,
  },
  {
    years: "2013 — 2019",
    title: "Design & Sales",
    body: "Various roles in design-adjacent sales. Learned how design products get specified, sold, and used — and started seeing workflows that felt obviously broken.",
  },
  {
    years: "2009 — 2013",
    title: "University",
    body: "Architecture and interior design. Learned to think about how people move through spaces, how operations shape physical layouts, and how constraints drive design decisions.",
  },
];

function Timeline() {
  // Entry 0 = AI (present, LEFT branch)
  // Entry 1 = Credit Sesame (present, RIGHT branch)
  // Entry 2 = Design & Sales (LEFT)
  // Entry 3 = University (RIGHT)
  const sides = ["left", "right", "left", "right"];

  return (
    <div className="timeline-zig">
      {/* NOW bracket */}
      <div className="tz-now">
        <span className="tz-now-label">NOW</span>
        <span className="tz-now-year">2026</span>
      </div>

      {/* The spine — a single SVG that spans the full section, centered */}
      <svg className="tz-spine" viewBox="0 0 200 1200" preserveAspectRatio="none" aria-hidden="true">
        {/* Fork at top for the two concurrent presents */}
        <path d="M100 0 L100 50 Q 100 90 70 110 L 70 200"
          stroke="var(--accent)" strokeWidth="1.2" fill="none"
          className="draw-line" style={{ transitionDelay: "200ms" }} />
        <path d="M100 0 L100 50 Q 100 90 130 110 L 130 200"
          stroke="var(--accent)" strokeWidth="1.2" fill="none"
          className="draw-line" style={{ transitionDelay: "400ms" }} />
        {/* Merge back to center */}
        <path d="M70 200 Q 70 240 100 260 L 100 300"
          stroke="var(--accent)" strokeWidth="1.2" fill="none"
          className="draw-line" style={{ transitionDelay: "600ms" }} />
        <path d="M130 200 Q 130 240 100 260"
          stroke="var(--accent)" strokeWidth="1.2" fill="none"
          className="draw-line" style={{ transitionDelay: "700ms" }} />
        {/* Main spine — center, dashed */}
        <line x1="100" y1="300" x2="100" y2="1200"
          stroke="var(--rule-strong)" strokeWidth="1"
          strokeDasharray="4 4" />
        {/* Endpoint marker */}
        <circle cx="100" cy="1200" r="3" fill="var(--rule-strong)" />
        {/* Branch marker dots */}
        <circle cx="70" cy="110" r="3.5" fill="var(--accent)" />
        <circle cx="130" cy="110" r="3.5" fill="var(--accent)" />
      </svg>

      <div className="tz-entries">
        {TIMELINE.map((t, i) => (
          <article
            className={`tz-entry tz-${sides[i]} ${t.now ? "tz-present" : ""} reveal`}
            key={i}
            style={{ transitionDelay: (i * 120) + "ms" }}
          >
            <div className="tz-card">
              {t.label && <span className="t-branch-label">{t.label}</span>}
              <span className="t-years">
                {t.now ? (
                  <>{t.years.replace("Present", "")}<span className="now">Present</span></>
                ) : t.years}
              </span>
              <h3 className="t-title">{t.title}</h3>
              <p className="t-body">{t.body}</p>
            </div>
            {/* Connector from card to spine — line only spans card edge to spine center */}
            <div className="tz-connector" aria-hidden="true">
              <svg viewBox="0 0 100 20" preserveAspectRatio="none">
                {sides[i] === "left" ? (
                  <>
                    <line x1="0" y1="10" x2="50" y2="10"
                      stroke="var(--rule-strong)" strokeWidth="1"
                      strokeDasharray="3 3" />
                    <circle className="tz-dot" cx="50" cy="10" r="3" />
                  </>
                ) : (
                  <>
                    <line x1="50" y1="10" x2="100" y2="10"
                      stroke="var(--rule-strong)" strokeWidth="1"
                      strokeDasharray="3 3" />
                    <circle className="tz-dot" cx="50" cy="10" r="3" />
                  </>
                )}
              </svg>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}

/* Gallery moved to variants.jsx */

/* Tweaks panel */
function TweaksPanel() {
  const { useState, useEffect } = React;
  const [state, setState] = useState(() => {
    try { return JSON.parse(localStorage.getItem("tweaks")) || {}; } catch (_) { return {}; }
  });
  const [on, setOn] = useState(false);

  const defaults = { theme: "dark", accent: "green", hero: "hex", projects: "list", tools: "field", heroMeta: "strip", gallery: "grid" };
  const v = { ...defaults, ...state };

  useEffect(() => {
    document.documentElement.dataset.theme = v.theme;
    const accentMap = {
      green: "#3BE081",
      amber: "#F0C869",
      coral: "#E27A6B",
      blue: "#7AB8E0",
    };
    document.documentElement.style.setProperty("--accent", accentMap[v.accent]);
    document.documentElement.dataset.hero = v.hero;
    const pl = document.querySelector(".projects-list");
    if (pl) pl.dataset.layout = v.projects;
    const tw = document.querySelector(".tools-wrap");
    if (tw) tw.dataset.layout = v.tools;
    // Broadcast so HeroMeta / Gallery components can react
    window.postMessage({ type: "__tweak_changed", key: "heroMeta", value: v.heroMeta }, "*");
    window.postMessage({ type: "__tweak_changed", key: "gallery", value: v.gallery }, "*");
    // Re-run reveal observer since variants remount their DOM
    setTimeout(() => { if (window.observeReveal) window.observeReveal(); }, 60);
    try { localStorage.setItem("tweaks", JSON.stringify(v)); } catch (_) {}
    window.parent.postMessage({ type: '__edit_mode_set_keys', edits: v }, '*');
  }, [v.theme, v.accent, v.hero, v.projects, v.tools, v.heroMeta, v.gallery]);

  useEffect(() => {
    function onMsg(e) {
      if (!e.data) return;
      if (e.data.type === "__activate_edit_mode") setOn(true);
      if (e.data.type === "__deactivate_edit_mode") setOn(false);
    }
    window.addEventListener("message", onMsg);
    window.parent.postMessage({ type: "__edit_mode_available" }, "*");
    return () => window.removeEventListener("message", onMsg);
  }, []);

  const set = (k, val) => setState(s => ({ ...s, [k]: val }));

  const Row = ({ label, k, opts }) => (
    <div className="tweak-row">
      <label>{label}</label>
      <div className="opts">
        {opts.map(o => (
          <button key={o.v}
            className={v[k] === o.v ? "active" : ""}
            onClick={() => set(k, o.v)}>{o.l}</button>
        ))}
      </div>
    </div>
  );

  return (
    <div className={"tweaks-panel" + (on ? " on" : "")}>
      <div className="tweaks-head">
        <span><span className="dot"/>Tweaks</span>
        <span>live</span>
      </div>
      <Row label="Theme" k="theme" opts={[{v:"dark",l:"Dark"},{v:"light",l:"Light"}]} />
      <div className="tweak-row">
        <label>Accent</label>
        <div className="swatches">
          {[
            {v:"green", c:"#3BE081"},
            {v:"amber", c:"#F0C869"},
            {v:"coral", c:"#E27A6B"},
            {v:"blue",  c:"#7AB8E0"},
          ].map(s => (
            <button key={s.v}
              className={"swatch-btn" + (v.accent === s.v ? " active" : "")}
              style={{ background: s.c }}
              onClick={() => set("accent", s.v)} />
          ))}
        </div>
      </div>
      <Row label="Hero variant" k="hero"
        opts={[{v:"hex",l:"Hex"},{v:"wire",l:"Wire"},{v:"type",l:"Type"}]} />
      <Row label="Projects layout" k="projects"
        opts={[{v:"list",l:"List"},{v:"grid",l:"Grid"},{v:"featured",l:"Featured"}]} />
      <Row label="Tools layout" k="tools"
        opts={[{v:"field",l:"Field"},{v:"grid",l:"Grid"},{v:"marquee",l:"Marquee"}]} />
      <Row label="Hero meta" k="heroMeta"
        opts={[{v:"strip",l:"Strip"},{v:"ticker",l:"Ticker"},{v:"coords",l:"Coords"}]} />
      <Row label="Gallery" k="gallery"
        opts={[{v:"grid",l:"Grid"},{v:"stacked",l:"Stacked"},{v:"sheet",l:"Sheet"}]} />
    </div>
  );
}

window.Timeline = Timeline;
window.Gallery = Gallery;
window.TweaksPanel = TweaksPanel;
